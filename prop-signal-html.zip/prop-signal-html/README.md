# Prop Firm Daily Signals (Pure HTML)

Simple one-page tool that runs the **Daily Engulfing + Failed Engulfing** strategy from your business plan.

Just open the page and press the big button.

## How to use on your existing GitHub website

1. Download `index.html`
2. Upload it to your GitHub Pages repo (any folder is fine)
3. Commit & push
4. Visit the URL, for example:
   - `https://yourusername.github.io/your-repo/index.html`
   - or `https://yourusername.github.io/your-repo/` if you put it in the root

That’s it. No Streamlit, no deployment steps, no API keys needed.

## Features

- Exact same pattern logic as the Colab code in your PDF
- Adjustable Account size, Risk %, and RR
- Clean dark UI with BUY (green) / SELL (red) cards
- Summary table
- Works on mobile

## Important notes about data

The page fetches daily candles directly from Yahoo Finance’s public chart endpoint.

- Most of the time it works fine from GitHub Pages.
- Occasionally Yahoo rate-limits or blocks browser requests. If that happens, just wait a few minutes and press the button again.
- Always double-check the numbers on your MT5 chart before trading.

## Local use

You can also just double-click `index.html` and open it in your browser (no server required).

---

Trading involves risk. This is an educational tool only.
